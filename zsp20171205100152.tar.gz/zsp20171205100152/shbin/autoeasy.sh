#!/bin/sh
################################################################################
##1.ȫ�ֱ���
################################################################################
#1.���𻷾���Ϣ����:�ű��ļ����λ��,���ݿ⻷������.��ϵͳshbinĿ¼�������ߵ����Ӽ���
tooldir=$HOME/priv/zsp/shbin
tooladminip=198.30.1.51
RM=/usr/bin/rm

tooldbusname=$USNAME
tooldbuspass=$USPASS
tooldboraclesid=$ORACLE_SID
toolftppath=/usr/bin/ftp
toolsftppath=/usr/bin/sftp
#toolsftpexpect=/lidp/shbin/sftp_tools/bin/expect
toolsftpexpect=${HOME}/tools/bin/expect

#2.����ȫ�ֱ�����Ϣ
if [ ! -d $tooldir ];then echo "$tooldir is not exist!"; exit 0; fi
today=$(date +%Y%m%d)
current=$(date +%Y%m%d%H%M%S)
toolname=$tooldir/autoeasy.sh
zfile=$tooldir/autoeasy.txt
#�û�����ģʽ:0-��ͨ����ģʽ,1-ָ���Ǳ����û�ģʽ,2-��¼����ģʽ
usemode="0"
srcipstring=$(who am i|awk '{print $NF}'|sed 's/(//'|sed 's/)//')
stat=$(sed -n '/^#:aelogininfo:/,/^#:/p' $zfile|grep -v "^#:"|awk '$1=="'$today'" && $3=="'$srcipstring'"'|tail -1|awk '{print $5}')
if [ "$stat" = "1" ];then
  srcipstring=$(sed -n '/^#:aelogininfo:/,/^#:/p' $zfile|grep -v "^#:"|awk '$1=="'$today'" && $3=="'$srcipstring'"'|tail -1|awk '{print $4}')
  usemode="2"
fi
if [ "$1" = "user" -a $# -ge 2 -a "$2" != "modify" -a "$2" != "login" ];then
  srcipstring2=$srcipstring
  if [ "$2" = "self" ];then
    loginstring=$(sed -n '/^#:aeuserinfo:const:/,/^#:/p' $zfile|grep -v "^#"|awk '$1=="'$srcipstring2'"'|tail -1)
  else
    loginstring=$(sed -n '/^#:aeuserinfo:const:/,/^#:/p' $zfile|grep -v "^#"|awk '$3=="'$2'"'|tail -1)
  fi
  if [ "$loginstring" = "" ];then echo "err!not find the user![$2]"; exit 1; fi
  if [ $# -eq 2 ];then echo $loginstring|awk '{printf "%s %s %s xxxxxx %s %s\n",$1,$2,$3,$5,$6}'; exit 0; fi
  srcipstring=$(echo  "$loginstring"|awk '{print $1}')
  if [ "$srcipstring" != "$srcipstring2" ];then
    usemode="1"
  fi
  shift
  shift
fi
ipstring=$(echo "$srcipstring"|awk -F. '{printf "%03d%03d%03d%03d",$1,$2,$3,$4}')
if [ $(expr length "$ipstring") -ne 12 ];then
  echo "err!serious sys err!"
  exit 1
fi
if [ -f $zfile ];then
  loginstring=$(sed -n '/^#:aeuserinfo:const:/,/^#:/p' $zfile|grep -v "^#"|awk '$2=="'$ipstring'"'|tail -1)
  loginname=$(echo  "$loginstring"|awk '{print $3}')
  loginpass=$(echo  "$loginstring"|awk '{print $4}')
  loginphone=$(echo "$loginstring"|awk '{print $5}')
  logindir=$(echo   "$loginstring"|awk '{print $6}')
fi
tooladminname=$(sed -n '/^#:aeuserinfo:const:/,/^#:/p' $zfile|grep -v "^#"|awk '$1=="'$tooladminip'"'|tail -1|awk '{print $3}')
homedir=$logindir
if [ "$homedir" = "" ];then
  homedir=$tooldir
fi
if [ ! -d $homedir ];then 
  echo "err!$homedir is not exist!";
  exit 1
fi
afile=$homedir/a$ipstring.txt
bfile=$homedir/b$ipstring.txt
ffile=$homedir/f$ipstring.txt
cfile=$homedir/c$ipstring.txt
dfile=$homedir/d$ipstring.txt
pfile=$homedir/p$ipstring.txt
tfile=$homedir/t$ipstring.txt
t1file=$homedir/t1$ipstring.txt
sfile=$homedir/s$ipstring.txt
gfile=$homedir/g$ipstring.sh
homebakdir=$homedir/toolbak
toolbakdir=$tooldir/toolbak
ftpdir=$homedir/ftp
ftpsenddir=$ftpdir/send
ftprecvdir=$ftpdir/recv
mkdir -p $homebakdir
mkdir -p $toolbakdir
mkdir -p $ftpdir
mkdir -p $ftpsenddir
mkdir -p $ftprecvdir
standline="--------------------------------------------------------------------------------"

################################################################################
##2.����ʹ��˵��
################################################################################
function Tooluse
{
tipnum=$(sed -n '/^#:aesmalltip:const:/,/^#:/p' $zfile|grep -v "^#"|grep -v "^$"|wc -l|awk '{print $1}')
tiptotnum=$(($RANDOM+1000000000))
tipindex=$(echo $(($tiptotnum%$tipnum+1)))
aesmalltip=$(sed -n '/^#:aesmalltip:const:/,/^#:/p' $zfile|grep -v "^#"|grep -v "^$"|head -$tipindex|tail -1)
if [ "$aesmalltip" = "" ];then
  aesmalltip="��һ��ʹ�øù��ߴ����������������ע������,ֻ��ע����ɲ���ʹ�øù���"
fi
clear
cat <<menu
autoeasy.sh����ʹ��ָ��:(��һ��ʹ�ô���user������κβ���������ע������)
--------------------------------------------------------------------------------
home      :�鿴���˹���Ŀ¼     |ע����Ϣ����name,pass,phone,workdir.ע����Ϣͨ��
user      :�鿴���������û���Ϣ |[ae user modify]������ʱ�޸�.[ae whoami]����
user  self:�鿴����ע����Ϣ     |[ae who am i]�鿴��ǰ��¼�û�,[ae user login]����
user login:��¼�Ѿ����ڵ��û�   |��¼�������û�.[ae user zhukebi f hello]�鿴�û�
bak       :���ݸ��˿��ļ�       |[zhukebi]��f�ļ���hello��ǩ,������ѯ�÷���ͬ.
--------------------------------------------------------------------------------
s         :�鿴ȫ·�������ļ�   |���߾������Ƶ��ļ�ϵͳ,�����ļ���Ϊϵͳ�ļ�����
s vi/view :�༭��鿴�ļ�����   |���ļ�.ϵͳ�ļ���[z]��ʾ,Ϊ�����û�������.�û�
s trun    :��ʱ�ļ��������     |�ļ��ַ�Ϊ��ʱ�ļ��Ϳ��ļ�,�ļ��������õ��ַ���
s ord     :��ʱ�ļ������������ |���û�IP�����,��ʱ�ļ�����[s/d/a/g],���ļ�����
s echo    :��ʱ�ļ��������ɽű� |[b/f/c/p],��g�ļ�����[.sh]Ϊ��׺���������ļ���
s cat     :�鿴�ļ����ݻ��ǩ   |��[.txt]��Ϊ��׺.���ļ��Ա�ǩΪ��λ������,��ǩ
g exec    :����g��ʱ�ű��ļ�    |�ĸ�ʽΪ[#:lab:type:desc],��ǩ��������,ɾ��,��
b lab     :��ȡ���ļ���ǩ��s�ļ�|�ĺͲ�ѯ,��ǩ������,�޸ĺͲ�ѯ�������s�ļ�����
b lab del :ɾ�����ļ���ǩ       |��.���ļ���ǩtypeΪ[sh]�ı�ǩ������Ϊ�ű���ִ��,
s d diff  :��ʱ�ļ����ݱȽ�     |typeΪ[const]�ı�ǩ������ɾ��.�����ļ�������ļ�
s d [user]:������ʱ�ļ�����     |Ϊ��ʱ�ļ���ֱ�ӿ���,���ָ���û��򿽱����û��ļ�
s c [user]:�������ļ���ǩ       |������ļ�Ϊ���ļ���ֻ�����ļ���ǩ,���Ϊϵͳ�ļ�
s filename:����ϵͳ�ļ�����     |�򿽱��ʼ�����.���ļ���ǩ������,�޸ĺ͸���ֻ��ͨ
c s       :�滻���ļ���ǩ       |��s�ļ������,������п��ļ���ǩ���ǽ���ǩ���ݴ�
c lab sh  :ִ�п��ļ���ǩ       |�ŵ�[g]�ļ���ִ��.ϵͳ�ļ�[z]Ҳ���ڿ��ļ�,������
c lab exec:���п��ļ���ǩ       |���ļ��еı�ǩ���Ա������û���ʹ��.
para 1 1  :��ȡtippara��������  |�ű����ܲ�����ȡ:��2��������ʾ������,��3��������
para 1 2  :��ȡtippara��������  |ʾ������.[para 1 3]��ʾ��1�е�3������.tippara��ʽ:
para 2 3  :��ȡtippara��������  |tippara="����������(eg:����),����������(eg:1234)"
--------------------------------------------------------------------------------
0 format  :����˳����и�ʽ���� |���߾���ǿ����ַ�����������,���߻��Զ���[s]�ļ�
1/n format:��ָ������и�ʽ���� |�е�Ԫ����ͨ��[format]��ʽ�ַ������б�׼�����,
format    :�����Դ��ĸ�ʽ�ַ��� |��1���������Ϊ[0]��������\$1\$2\$3�滻��ʽ�ַ�
1 memset  :��memset��ʽ������   |���е�[%s]���Ϊ�����������ʾ��ָ�����滻.����
n format 0:������������������ |�Դ�������׼��ʽ�ַ���,ֻ��Ҫ������ǩ���ɵ���.
n cond    :��ʽ������ѡ����   |��������:
0 ">%s>"  :��ָ��%s��ת���ɴ�д |[<!if(c1)then{f1}elif(c2)then{f2}else{f3}!>]
0 "<%s<"  :��ָ��%s��ת����Сд |����:c1[-ive 2 c1],i-���Դ�Сд,v-��(ȡ��),e-���
0 "<\$2<"  :����2��ת����Сд    |2-��ʾ��2����(���Ϊ0��ʾ����),���������������.
n cond    :��ʽ������ѡ����   |��ͬ�������:��[c1]&&[c2],��[c1]||[c2],�ɶ�����
n cond    :��ʽ������ѡ����   |��ʽ�ַ���:������[\$line],��ʾ��[{}],����ʾ[\$del]
--------------------------------------------------------------------------------
sql sqlstr:[sql]�������ݿ����  |sqlstr:[select * from t_zero_acc_ctrl]
tb  tbname:[sql]��ѯ���ṹ��Ϣ  |tbname:[t_zero_acc_ctrl]
cal 1+1   :[sql]������ѧ����ʽ  |����ʽ:[3+4*(5+6)]
ftp get ..:[ftp]ftp�����ļ�     |����:[ip ftpname ftppwd remote-full-filename]
ftp put ..:[ftp]ftp�ϴ��ļ�     |����:[ip ftpname ftppwd curdir-filename remotedir]
find tag 1:�����ִ�Сд��ȡ�ֶ� |��ȡ[s]�ļ��к���tag����,[1]��ʲô��ͷ.
--------------------------------------------------------------------------------
С��ʾ:��$aesmalltip��
--------------------------------------------------------------------------------
menu
}

################################################################################
##3.�⺯��
################################################################################
#1.�Ƿ�Ϊ���� 0-��,1-��
function isdigit
{
  type=$(echo "$1"|sed 's/[0-9]//g')
  if [ "$type" = "" -a ! "$1" = "" ];then
    echo 1
  else
    echo 0
  fi
}

#2.�Ƿ�Ϊ���֡��ַ����»������.0-��,1-��
function islabel
{
  type=$(echo "$1"|sed 's/[0-9a-zA-Z_]//g')
  if [ "$type" = "" -a ! "$1" = "" ];then
    echo 1
  else
    echo 0
  fi
}

#3.ȥ���ַ�����β��[/. ]����
function trimtail
{
  str1="$1"
  str2=$(echo "$str1"|sed 's/[\/\. ]$//')
  while [ "$str2" != "$str1" ]
  do
    str1="$str2"
    str2=$(echo "$str1"|sed 's/[\/\. ]$//')
  done
  echo "$str1"
}

#4.��дת��
function upper
{
  string=$(echo "$1"|tr "[a-z]" "[A-Z]");
  echo "$string";
}

#5.Сдת��
function lower
{
  string=$(echo "$1"|tr "[A-Z]" "[a-z]");
  echo "$string";
}

#6.str1 str2 1/0 -- 1no case,0case
function strstr
{
  if [ $# -ne 3 -o "$3" = "" -o $(expr length "$2") -gt $(expr length "$1") -o $(expr length "$2") -eq 0 ];then
    echo 0
  else
    if [ $3 -eq 1 ];then
      s2=$(echo "$2"|sed 's/ //g')
      s2=$(lower "$s2")
      string=$(echo "$1"|sed 's/ //g')
      string=$(lower "$string")
      string=$(echo "$string"|sed 's/'$s2'//g')
    else
      s2=$(echo "$2"|sed 's/ //g')
      string=$(echo "$1"|sed 's/ //g'|sed 's/'$s2'//g')
    fi
    if [ $(expr length "$1") -gt $(expr length "$string") ];then
      echo 1
    else
      echo 0
    fi
  fi
}

#7.��ȡ�еĳ����ַ���
function getlnstring
{
  maxlie=$(cat $1|grep -v "^#"|awk '{print NF}'|sort|tail -1)
  if [ "$maxlie" = "" ];then maxlie=0;fi
  i=1
  lnstring=""
  while [ $i -le $maxlie ]
  do
    ln=$(cat $1|grep -v "^#"|awk '{print length($('$i'))}'|sort -n|tail -1)
    lnstring="$lnstring""$ln"" "
    i=$(expr $i + 1)
  done
  echo "$lnstring"
}

#8.echo �ı���ԭ
function dealecho
{
  cat $1|sed 's/\\/<nnnn>/g'|sed 's/ //g'|sed 's/    //g'|while read line
  do
    line=$(echo "$line"|sed 's/\"/\\\"/g'|sed 's/\$/\\\$/g'|sed 's/<nnnn>/\\\\\\\\\\\\\\\\/g'|sed 's// /g'|sed 's//    /g')
    echo "echo \"""$line""\""
  done
  exit 0;
}

#9.��Դ�ļ�������
function dealorder
{
  lnstring=$(getlnstring $1)
  cat $1|while read line
  do
    string=""
    j=$(echo "$line"|awk '{print NF}');
    i=1;
    while [ $i -le $j ]
    do
      ln=$(echo "$lnstring"|awk '{print $('$i')}')
      f=`echo "$line"|awk '{printf $('$i')}'|awk '{printf "%-"'$ln'"s",$1}'|sed 's/ //g'`;
      string="$string""$f"" "
      i=$(expr $i + 1)
    done
    string=`echo "$string"|sed 's// /g'`
    echo "$string"
  done
}

################################################################################
##4.Ӧ�ú���
################################################################################
#1.���������ֶ� 1-vie,2-line,2-cond2
function dealcondpara
{
  cond1="$1"
  line="$2"
  cond="$3"
  ibool=1
  if [ $(strstr "$cond1" "i" 0) -eq 1 -a $(strstr "$cond1" "e" 0) -eq 1 ];then
    if [ $(strstr "$line" "$cond" 1) -eq 0 -o $(strstr "$cond" "$line" 1) -eq 0 ];then
      ibool=0
    fi
  else
    if [ $(strstr "$cond1" "i" 0) -eq 1 ];then
      if [ $(strstr "$line" "$cond" 1) -eq 0 ];then
        ibool=0
      fi
    fi
    if [ $(strstr "$cond1" "e" 0) -eq 1 ];then
      if [ "$line" != "$cond" ];then
        ibool=0
      fi
    fi
  fi
  if [ $(strstr "$cond1" "v" 0) -eq 1 ];then
    if [ "$ibool" = "0" ];then
      ibool=1
    else
      ibool=0
    fi
  fi
  echo $ibool
}

#2.�������� 1-�ַ��� 2-����(�����Ժ��пո�) ����[-ie 1 cond]
function atomcondition
{
  cond="$2"
  line="$1"
  num=$(echo "$cond"|awk '{print NF}')
  ibool=0
  if [ $num -eq 1 ];then
    if [ $(strstr "$line" "$cond" 0) -eq 1 ];then
      ibool=1
    fi
  elif [ $num -eq 2 ];then
    cond1=$(echo "$cond"|awk '{print $1}')
    cond2=$(echo "$cond"|awk '{print $2}')
    if [ $(isdigit "$cond1") -eq 1 ];then
      if [ $cond1 -ne 0 ];then
        line=$(echo "$line"|awk '{print $'$cond1'}')
      fi
      if [ $(strstr "$line" "$cond2" 0) -eq 1 ];then
        ibool=1
      fi
    else
      first=$(echo "$cond1"|cut -c1-1)
      cond1=$(echo $cond1|sed 's/-//g')
      if [ "$first" = "-" ];then
        ibool=$(dealcondpara "$cond1" "$line" "$cond2")
      fi
    fi
  elif [ $num -eq 3 ];then
    cond1=$(echo "$cond"|awk '{print $1}')
    cond2=$(echo "$cond"|awk '{print $2}')
    cond3=$(echo "$cond"|awk '{print $3}')
    first=$(echo "$cond1"|cut -c1-1)
    cond1=$(echo $cond1|sed 's/-//g')
    if [ "$first" = "-" -a $(isdigit "$cond2") -eq 1 -a "$cond3" != "" ];then
      if [ $cond2 -ne 0 ];then
        line=$(echo "$line"|awk '{print $'$cond2'}')
      fi
      ibool=$(dealcondpara "$cond1" "$line" "$cond3")
    fi
  fi
  echo $ibool
}

#3.��ָ���ļ���ʽ�����,$1Դ�ļ�,$2-0/1/2,$3��ʽ�ַ���,$4���⴦����ʶ-mode:0-�ֶβ�����
function FormatFile
{
  mode=1
  condition="<!if()then{}elif()then{}else{}!>"
  head=$(echo $condition|awk -F '{print $1}')
  tail=$(echo $condition|awk -F '{print $NF}')
  head2=$(echo "$3"|cut -c1-$(expr length $head))
  tail2=$(echo "$3"|cut -c$(expr $(expr length "$3") - $(expr length $tail) + 1)-$(expr length "$3"))
  if [ $tail = "$tail2" -a $head = "$head2" ];then
    mode=2
  fi

  if [ $mode -eq 2 ];then
    string=$(echo "$3"|sed 's/'$head'//g'|sed 's/'$tail'//g')
    icond=$(echo $condition|awk -F '{print NF}')
    while [ $icond -ge 0 ]
    do
      split=$(echo $condition|awk -F '{print $('$icond')}')
      string=$(echo "$string"|sed 's/'$split'//g')
      icond=$(expr $icond - 1)
    done
    if [ $(expr $(echo "$string"|awk -F '{print NF}') % 2 ) -ne 1 ];then
      echo "err!para err!1"
      exit 1
    fi
  fi

  if [ $mode -eq 1 ];then
    format=`echo "$3"|sed 's/ //g'`
    format=`echo "$format"|sed 's/%%s/\\$\\$/g'`
    if [ $2 -gt 0 ]; then
      format=`echo "$format"|sed 's/%s/\\$'$2'/g'`
    else
      i=1
      irep=$(echo "$3"|sed 's/%s//g'|awk -F '{print NF}')
      while [ $i -le $irep ]
      do
        format=$(echo "$format"|sed 's/%s/$'$i'/')
        i=$(expr $i + 1)
      done
    fi
  fi
  
  lnstring=$(getlnstring $1)
  if [ "$4" = "0" ];then
    fieldnum=$(echo $lnstring|awk '{print NF}')
    i=1
    lnstring=""
    while [ $i -le $fieldnum ]
    do
      if [ $i -eq 1 ];then
        lnstring="0"
      else
        lnstring="$lnstring"" 0"
      fi
      i=$(expr $i + 1)
    done
  fi

  #�����ַ�����: '/' <--> [0X2F]
  cat $1|sed 's/\//[0X2F]/g'|while read line
  do
    if [ $(echo "$line"|sed 's/ //g'|awk '{print length}') -eq 0 ];then
      echo ""
      continue
    fi
    firststring=$(echo "$line"|cut -c1-1)
    if [ "$firststring" = "#" ];then
      continue
    fi
    if [ $mode -eq 2 ];then
      format=""
      i=1
      j=$(echo "$string"|awk -F '{print NF}')
      while [ $i -le $j ]
      do
        if [ $i -eq $j ];then
          format=$(echo "$string"|awk -F '{print $NF}')
          break
        fi
        cond=$(echo "$string"|awk -F '{print $('$i')}')
        #cond:[c1]&&[c2]||[c3]&&[c4]
        first=$(echo "$cond"|cut -c1-1)
        last=$(echo "$cond"|cut -c$(expr length "$cond")-$(expr length "$cond"))
        imult=1
        if [ "$first" = "[" ];then
          imult=$(expr $imult + 1)
        fi
        if [ "$last" = "]" ];then
          imult=$(expr $imult + 1)
        fi
        if [ $(strstr "$cond" "\]&&\[" 0) -eq 1 -o $(strstr "$cond" "\]||\[" 0) -eq 1 ];then
          imult=$(expr $imult + 1)
        fi
        if [ $imult -ge 4 ];then
          cond=$(echo "$cond"|cut -c2-$(expr $(expr length "$cond") - 1))
          cond2=$(echo "$cond"|sed 's/\]&&\[//g'|sed 's/\]||\[//g')
          cond3=$(echo "$cond"|sed 's/ //g')
          x=$(echo "$cond2"|awk -F '{print NF}')
          y=1
          while [ $y -le $x ]
          do
            z=$(echo "$cond2"|awk -F '{print $('$y')}')
            m=$(atomcondition "$line" "$z")
            z=$(echo "$z"|sed 's/ //g')
            cond3=$(echo "$cond3"|sed 's/'$z'/'$m'/')
            y=$(expr $y + 1)
          done
          while [ $(expr length "$cond3") -ne 1 ]
          do
            cond3=$(echo "$cond3"|sed 's/0\]&&\[0/0/g'|sed 's/0\]&&\[1/0/g'|sed 's/1\]&&\[0/0/g'|sed 's/1\]&&\[1/1/g')
            cond3=$(echo "$cond3"|sed 's/0\]||\[0/0/g'|sed 's/0\]||\[1/1/g'|sed 's/1\]||\[0/1/g'|sed 's/1\]||\[1/1/g')
          done
          ibool=$(echo "$cond3")
        else
          ibool=$(atomcondition "$line" "$cond")
        fi
        if [ $ibool -eq 1 ];then
          format=$(echo "$string"|awk -F '{print $('$(expr $i + 1)')}')
          break
        fi
        i=$(expr $i + 2)
      done
    fi

    if [ $mode -eq 2 ];then
      format=`echo "$format"|sed 's/ //g'`
      format=`echo "$format"|sed 's/%%s/\\$\\$/g'`
      if [ $2 -gt 0 ]; then
        format=`echo "$format"|sed 's/%s/\\$'$2'/g'`
      else
        i=1
        irep=$(echo "$3"|sed 's/%s//g'|awk -F '{print NF}')
        while [ $i -le $irep ]
        do
          format=$(echo "$format"|sed 's/%s/$'$i'/')
          i=$(expr $i + 1)
        done
      fi
    fi
    
    format2="$(echo "$format")";
    
    #jȡ�����ĸ���Ҫ�ȵ�ǰ����ĸ�����һ��,������ȫ���滻$
    j=$(echo "$lnstring"|awk '{print NF}')
    i=$j;
    while [ $i -ge 1 ]
    do
      ln=$(echo "$lnstring"|awk '{print $('$i')}')
      tmp=$(echo ${line}|awk '{printf $('$i')}')
      if [ "$tmp" = "" ];then
        f=$(echo |awk '{printf "%-"'$ln'"s",$1}'|sed 's/ //g');
      else
        f=$(echo "$tmp"|awk '{printf "%-"'$ln'"s",$1}'|sed 's/ //g');
      fi
      format2=`echo "$format2"| sed 's/>\$'$i'>/'$(upper "$f")'/g'`
      format2=`echo "$format2"| sed 's/<\$'$i'</'$(lower "$f")'/g'`
      format2=`echo "$format2"| sed 's/\$'$i'/'$f'/g'`
      i=$(expr $i - 1)
    done
    format2=`echo "$format2"|sed 's/\\$\\$/%s/g'`
    format2=`echo "$format2"|sed 's/\$n/\\\\\\\\n/g'`
    format2=`echo "$format2"|sed 's// /g'`
    if [ "$format2" = "\$line" ];then
      echo $line|sed 's/\[0X2F\]/\//g'
    elif [ "$format2" = "\$del" ];then
      continue
    elif [ "$format2" = "" ];then
      echo ""
    else
      echo "$format2"|sed 's/\[0X2F\]/\//g'
    fi
  done
}


#4.��ȡ�ļ���tag��sfile,1-file,2-tag
function getfiletag
{
  sed -n '/^'#:$2:'/,/^#:/'p $1 >$tfile
  head -1 $tfile
  sed -n '/^'#:$2:'/,/^#:/'p $tfile|grep -v "^#:"
}

#5.ɾ���ļ�tag,1-tagfile,2-tag,3-null/0(no yes)
function delfiletag
{
  tagfile=$1
  tag=$2
  yesflag=$3
  flag1="#:$tag:"
  totl=$(wc -l $tagfile|awk '{print $1}')
  body=$(sed -n '/^'$flag1'/,/^#:/'p $tagfile|wc -l|awk '{print $1}')
  if [ $body -le 0 ];then 
    echo "err!no tag find"; 
    exit 1
  fi
  tmp=$(sed -n '/^'$flag1'/,/^#:/'p $tagfile|tail -1|cut -c1-2)
  if [ $body -gt 1 -a "$tmp" = "#:" ];then
    body=$(expr $body - 1)
  fi
  if [ "$yesflag" != "0" ];then
    echo "--------------------------------------------------------------------------------"
    sed -n '/^'$flag1'/,/^#:/'p $tagfile|head -$body
    echo "--------------------------------------------------------------------------------"
    echo "confirm delete tagcontent up?"
    echo "(y/n):"
    read flag2
    if [ "$flag2" != "y" ];then
      echo "you give up!"
      exit 0
    fi
  fi
  tmp=$(sed -n '/^'$flag1'/,/^#:/'p $tagfile|head -1|awk -F: '{print $3}')
  if [ "$tmp" = "const" ];then
    echo "err!you cannot del const tag!"
    exit 1
  fi
  line=1
  tmp=$(head -1 $tagfile|cut -c1-$(expr length "$flag1"))
  if [ "$tmp" != "$flag1" ];then
    line=$(sed -n '1,/^'$flag1'/'p $tagfile|wc -l|awk '{print $1}')
  fi
  time=$(date +%Y%m%d%H%M%S)
  cp $tagfile $tfile
  if [ $? -ne 0 ];then
    echo "err!del err!please check the file system space!"
    exit 1
  fi
  safectrl=0
  >$tagfile
  safectrl=$(expr $safectrl + $?)
  head -$(expr $line - 1) $tfile >>$tagfile
  safectrl=$(expr $safectrl + $?)
  tail -$(expr $totl - $line - $body + 1) $tfile >>$tagfile
  safectrl=$(expr $safectrl + $?)
  if [ $safectrl -ne 0 ];then
    echo "err!del err!please check the file system space![$safectrl]"
    cp $tfile $tagfile
    if [ $? -ne 0 ];then
      echo "err!recover $tagfile err!"
      echo "please recover it by hand!"
      echo "command:[cp $tfile $tagfile]"
    fi
  else
    if [ "$3" != "0" ];then
      echo "del tag $2 success!"
    fi
    >$tfile
  fi
}
#6.�����ǩ 1-tagfile 
function savefiletag
{
  tagfile=$1
  tagfile2=$(echo $tagfile|awk -F/ '{print $NF}'|cut -c1-1)
  flag1=$(head -1 $sfile|cut -c1-2)
  flag2=$(head -1 $sfile|awk -F: '{print NF}')
  flag3=$(head -1 $sfile|awk -F: '{print $2}')
  flag4=$(cat $sfile|grep ^#:|wc -l|awk '{print $1}')
  if [ "$flag1" = "" -o "$flag2" = "" -o "$flag3" = "" -o "$flag4" = "" ];then
    echo "err!the data in sfile format err!"
    exit 1
  fi
  if [ "$flag1" != "#:" -o $flag2 -lt 3 -o $(islabel "$flag3") -eq 0 -o $flag4 -gt 1 ];then
    echo "err!the data in sfile format err!"
    exit 1
  fi
  flag5="#:"$flag3":"

  flag1="#:"$flag3":"
  totl=$(wc -l $tagfile|awk '{print $1}')
  body=$(sed -n '/^'$flag1'/,/^#:/'p $tagfile|wc -l|awk '{print $1}')
  if [ $body -le 0 ];then
    cat $sfile >>$tagfile
    echo "save success!"
    return
  fi
  tmp=$(sed -n '/^'$flag1'/,/^#:/'p $tagfile|tail -1|cut -c1-2)
  if [ $body -gt 1 -a "$tmp" = "#:" ];then
    body=$(expr $body - 1)
  fi
  if [ $2 != "0" ];then
    sed -n '/^'$flag1'/,/^#:/'p $tagfile|head -$body >$tfile
    echo "diff "$tagfile2"file.$flag3 sfile"
    echo "--------------------------------------------------------------------------------"
    diff $tfile $sfile
    if [ $? -eq 0 ];then
      echo "sfile is same to "$tagfile2"file.$flag3!"
      >$tfile
      exit 0
    fi
    >$tfile
    echo "--------------------------------------------------------------------------------"
    echo "confirm using sfile to replace "$tagfile2"file.$flag3!"
    echo "(y/n):"
    read flag2
    if [ "$flag2" != "y" ];then
      echo "you give up!"
      exit 0
    fi
  fi
  line=1
  tmp=$(head -1 $tagfile|cut -c1-$(expr length "$flag1"))
  if [ "$tmp" != "$flag1" ];then
    line=$(sed -n '1,/^'$flag1'/'p $tagfile|wc -l|awk '{print $1}')
  fi
  time=$(date +%Y%m%d%H%M%S)
  cp $tagfile $tfile
  if [ $? -ne 0 ];then
    echo "err!save err!please check the file system space!"
    exit 1
  fi
  safectrl=0
  >$tagfile
  safectrl=$(expr $safectrl + $?)
  head -$(expr $line - 1) $tfile >>$tagfile
  safectrl=$(expr $safectrl + $?)
  cat $sfile >>$tagfile
  safectrl=$(expr $safectrl + $?)
  tailnum=$(expr $totl - $line - $body + 1)
  if [ $tailnum -gt 0 ];then
    tail -$(expr $totl - $line - $body + 1) $tfile >>$tagfile
    safectrl=$(expr $safectrl + $?)
  fi
  if [ $safectrl -ne 0 ];then
    echo "err!save err!please check the file system space![$safectrl]"
    cp $tfile $tagfile
    if [ $? -ne 0 ];then
      echo "err!recover $tagfile err!"
      echo "please recover it by hand!"
      echo "command:[cp $tfile $tagfile]"
    fi
  else
    if [ $2 != "0" ];then
      echo "save tag $flag3 success!"
    fi
    >$tfile
  fi
}

#7.�Ѵ����û���¼ aelogininfo:20170428 093030 198.30.1.51 198.30.1.57 0/1(0-��¼,1-�ǳ�)
function dealsecondlogin
{
  var1=$(who am i|awk '{print $NF}'|sed 's/(//'|sed 's/)//')
  var2=$(sed -n '/^#:aelogininfo:const:/,/^#:/p' $zfile|awk '$1=="'$today'" && $3=="'$var1'"'|tail -1)
  if [ "$var2" != "" ];then
    var21=$(echo $var2|awk '{print $4}')
    var22=$(sed -n '/^#:aeuserinfo:/,/^#:/p' $zfile|grep -v "^#"|awk '$1=="'$var21'"'|tail -1|awk '{print $3}')
    var23=$(echo $var2|awk '{print $5}')
    echo "current aelogininfo:"
    echo "��¼���� ��¼ʱ�� �Լ�IP ��¼IP ��¼�û��� ��ǰ״̬"|awk '{printf "%-8s %-8s %-15s %-15s %-12s %s\n",$1,$2,$3,$4,$5,$6}'
    echo "$var2(1-��¼/2-�ǳ�) $var22"|awk '{printf "%-8s %-8s %-15s %-15s %-12s %s\n",$1,$2,$3,$4,$6,$5}'
  else
    echo "������δ��¼�������û�!"
  fi
  echo "input:(1-��¼/2-�ǳ�):"|awk -F, '{printf "%s",$1}'
  read var
  if [ "$var" != "1" -a "$var" != "2" ];then
    echo "err!input err![$var]"
    exit 1
  fi
  if [ "$var" = "2" -a "$var2" = "" ];then
    echo "err!������δ��¼��,����Ҫ�ǳ�!"
    exit 1
  fi
  if [ "$var" = "2" -a "$var23" = "2" ];then
    echo "err!��ǰ״̬�Ѿ�Ϊ�ǳ�״̬![$var][$var23]"
    exit 1
  fi
  if [ "$var" = "1" -a "$var23" = "1" ];then
    echo "err!��ǰΪ��¼״̬,���ȵǳ��ٵ�½�����û�!"
    exit 1
  fi
  echo "input login user name:"|awk -F, '{printf "%s",$1}'
  read var3
  if [ "$var" = "2" -a "$var3" != "$var22" ];then
    echo "err!�û����������![$var3]"
    exit 1
  fi
  var32=$(sed -n '/^#:aeuserinfo:/,/^#:/p' $zfile|grep -v "^#"|awk '$3=="'$var3'"'|tail -1|awk '{print $1}')
  if [ "$var1" = "$var32" ];then
    echo "err!û��Ҫ���Լ���IP�ֶ���¼�Լ����û�![$var1]"
    exit 1
  fi
  echo "input login user pass:"|awk -F, '{printf "%s",$1}'
  read var31
  var4=$(sed -n '/^#:aeuserinfo:/,/^#:/p' $zfile|grep -v "^#"|awk '$3=="'$var3'" && $4=="'$var31'"'|tail -1|awk '{print $1}')
  if [ "$var4" = "" ];then
    echo "err!login failed!wrong name or password![$var3/$var31]"
    exit 1
  fi
  var5=$(grep "^#:aelogininfo:" $zfile|wc -l|awk '{print $1}')
  var6=$(date +%H%M%S)
  if [ $var5 -eq 0 ];then
    echo "#:aelogininfo:const:�û���¼��Ϣ��" >$sfile
    echo "$today $var6 $var1 $var4 $var" >>$sfile
  elif [ $var5 -eq 1 ];then
    sed -n '/^#:aelogininfo:/,/^#:/p' $zfile|head -1 >$sfile
    sed -n '/^#:aelogininfo:/,/^#:/p' $zfile|grep -v "^#:" >>$sfile
    echo "$today $var6 $var1 $var4 $var" >>$sfile
  elif [ $var5 -gt 1 ];then
    echo "err!more than one tag in file![$var6]"
    exit 1
  fi
  savefiletag $zfile 0
  echo "deal login success!"
  $RM $sfile 2>/dev/null
  exit 0
}

#8.�û�ע�� ,0-���û�ע��,1-�޸ĸ�����Ϣ
function dealfirstlogin
{
  logintype=$1
  if [ $logintype -eq 0 ];then
    echo "Its first time you use this tool!"
    echo "please finish your base information!"
  fi
  if [ $logintype -eq 1 ];then
    echo "now you can modify your infomation!"
    echo "--------------------------------------------------------------------------------"
    echo "$loginstring"|awk '{printf "old info:\nname    :%s\npassword:%s\nphone   :%s\nworkdir :%s\n",$3,$4,$5,$6}'
  fi
  echo "--------------------------------------------------------------------------------"
  while true
  do
    echo "please input your name"|awk -F, '{printf "%s:",$1}'
    read name
    if [ $logintype -eq 1 -a "$name" = "" ];then name=$(echo "$loginstring"|awk '{print $3}');fi
    temp=$(echo "$name"|sed 's/ //g')
    if [ "$temp" != "$name" -o "$name" = "" -o $(expr length "$name") -lt 4 ];then
      echo "err!format err!please input again!"
    elif [ $(sed -n '/^#:aeuserinfo:const:/,/^#:/p' $zfile|grep -v "^#"|awk '$3=="'$temp'"'|wc -l|awk '{print $1}') -ge 1 -a "$name" != "$loginname" ];then
      echo "err!name has been used!please input a new name!"
    else
      break
    fi
  done
  while true
  do
    echo "please input your password(use six digit)"|awk -F, '{printf "%s:",$1}'
    read password
    if [ $logintype -eq 1 -a "$password" = "" ];then password=$(echo "$loginstring"|awk '{print $4}');fi
    temp=$(echo "$password"|sed 's/[0-9]//g')
    if [ "$temp" != "" -o "$password" = "" -o $(expr length "$password") -ne 6 ];then
      echo "err!format err!please input again!"
    else
      break
    fi
  done
  while true
  do
    echo "please input your phone no(use eleven digit)"|awk -F, '{printf "%s:",$1}'
    read phone
    if [ $logintype -eq 1 -a "$phone" = "" ];then phone=$(echo "$loginstring"|awk '{print $5}');fi
    temp=$(echo "$phone"|sed 's/[0-9]//g')
    if [ "$temp" != "" -o "$phone" = "" -o $(expr length "$phone") -ne 11 ];then
      echo "err!format err!please input again!"
    else
      break
    fi
  done
  while true
  do
    echo "please input your priv work dir(eg:$homedir)"|awk -F, '{printf "%s:",$1}'
    read workdir
    if [ $logintype -eq 1 -a "$workdir" = "" ];then workdir=$(echo "$loginstring"|awk '{print $6}');fi
    workdir=$(echo "$workdir"|sed 's/ //g')
    workdir=$(trimtail "$workdir")
    firstchar=$(echo "$workdir"|cut -c1-1)
    if [ ! -d "$workdir" -o "$firstchar" != "/" -o $(expr length "$workdir") -le $(expr length "$HOME/priv/") ];then
      echo "err!input err!please input again!"
    elif [ "$workdir" = "$tooldir" ];then
      echo "err!you can't use this dir!please input again!"
    else
      break
    fi
  done
  if [ $logintype -eq 1 -a "$name" = "$loginname" -a "$password" = "$loginpass" -a "$phone" = "$loginphone" -a "$workdir" = "$logindir" ];then
    echo "err!no info modified!"
    exit 0
  fi
  if [ $(sed -n '/^#:aeuserinfo:const:/p' $zfile|wc -l|awk '{print $1}') -le 0 ];then
    echo "#:aeuserinfo:const:�û���Ϣ�Ǽ�"  >$sfile
  else
    #getfiletag $zfile "aeuserinfo"
    getfiletag $zfile "aeuserinfo" >$sfile;>$tfile
    if [ $logintype -eq 1 ];then
      cat $sfile >$tfile
      cat $tfile|awk '$2!="'$ipstring'"' >$sfile
      >$tfile
    fi
  fi
  echo "$srcipstring $ipstring $name $password $phone $workdir" >>$sfile
  savefiletag $zfile 0
  if [ "$workdir" != "$homedir" ];then
    mkdir -p $workdir/toolbak
    if [ $logintype -eq 1 ];then
      mv $homedir/*$ipstring.txt $workdir 1>/dev/null 2>&1
      mv $homedir/toolbak/*$ipstring.txt.*  $workdir/toolbak 1>/dev/null 2>&1
    fi
  fi
  echo "--------------------------------------------------------------------------------" 
  if [ $logintype -eq 0 ];then
    $RM [sdatbpcf]$ipstring.txt 2>/dev/null
    $RM [g]$ipstring.sh 2>/dev/null
    echo "regin success!you can use this tool now!"
  fi
  if [ $logintype -eq 1 ];then
    >$sfile 
    echo "modify success!you can use this tool now!"
  fi
}

#9.�������ݿ��ѯ���
function runsql
{
  sqlstr="$1"
  >$tfile
  sqlplus $tooldbusname/$tooldbuspass@$tooldboraclesid <<! >>$tfile
      set lines 3000;
      set head off;
      set feedback off ;
      set heading off ;
      set verify off ;
      set trimspool off;
      select '---begin---' from dual;
      $sqlstr;
      select '---end---' from dual;
!
  totline=$(sed -n '/---begin---/,/---end---/'p $tfile|wc -l);
  if [ $totline -le 3 ];then
    return
  fi
  sed -n '/---begin---/,/---end---/'p $tfile|head -$(expr $totline - 2)|tail -$(expr $totline - 4)|sed '/./!d'
  >$tfile
}

#10.����ftp���� para:p1:get/put,p2-ip,p3-loginname,p4-password,p5-filename,p6-rdir
#get��ftp/recvĿ¼,put��ָ��Ŀ¼
function runftp
{
  ftptype=$1
  ftpip=$2
  ftpusr=$3
  ftppwd=$4
  ftpfile=$5
  ftprdir=$6
  filename=$(echo $ftpfile|awk -F[/] '{print $NF}')
  first=$(echo $ftpfile|cut -c1-1)
  #if [ "$first" = "/" ];then
  #  ftpdir=$(echo $ftpfile|cut -c1-$(expr $(expr length "$ftpfile") - $(expr length "$filename") ))
  #fi
  if [ "$ftptype" = "get" ];then
    ftpdir=$ftprecvdir
  elif [ "$ftptype" = "put" ];then
    ftpdir=$ftpsenddir
    if [ ! -f $ftpfile ];then
      echo "err!file [$ftpfile] not exist!"
      exit 1
    fi
    cp $ftpfile $ftpdir
  else
    echo "err!type err![$ftptype]"
    exit 1
  fi
  ftptxt=$ftpdir/$filename.ftp
  curdir=`pwd`
  cd $ftpdir
  >$ftptxt
  echo "user $ftpusr $ftppwd ">>$ftptxt
  echo "bin" >>$ftptxt
  echo "hash" >>$ftptxt
  echo "prompt off" >>$ftptxt
  echo "binary" >>$ftptxt
  if [ "$ftprdir" != "" ];then
    echo "cd $ftprdir" >>$ftptxt
  fi
  if [ "$ftptype" = "get" ];then
	if [ "$ftprdir" != "" ];then
      echo "mget $filename" >>$ftptxt
	else
      echo "mget $ftpfile" >>$ftptxt
	fi
  elif [ "$ftptype" = "put" ];then
    echo "mput $filename" >>$ftptxt
  fi
  echo "bye" >>$ftptxt
  $toolftppath -v -n $ftpip < $ftptxt
  if [ "$ftptype" = "get" ];then
    if [ ! -f $filename ];then
      echo "err!get file failed!"
    else
      echo "get file success"
    fi
  elif [ "$ftptype" = "put" ];then
    echo "put success!"
  fi
  cd $curdir
}

#10.����sftp���� para:p1:get/put,p2-ip,p3-loginname,p4-password,p5-filename,p6-rdir,p7-count
#echo $(sftp $3@$4 <<!
#lcd $(dirname $1)
#cd $REMOTEDIR
#put $LOCALFILE
#bye
#!)
function runsftpput
{
  if [ "$1" = "get" ];then
    echo $(sftp $3@$2 <<!lcd $ftprecvdir;cd $6;put $filename;bye;!)
  elif [ "$1" = "put" ];then
    echo $(sftp $3@$2 <<!lcd $ftprecvdir;cd $6;put $filename;bye;!)
  fi
}
function runsftp
{
  sftptype=$1
  sftpip=$2
  sftpusr=$3
  sftppwd=$4
  sftpfile=$5
  sftprdir=$6
  sftpputnum=$7
  if [ "$sftpputnum" = "" ];then
    sftpputnum=3
  fi
  filename=$(echo $sftpfile|awk -F[/] '{print $NF}')

  if [ "$sftptype" = "get" ];then
    sftpdir=$ftprecvdir
  elif [ "$sftptype" = "put" ];then
    sftpdir=$ftpsenddir
    if [ ! -f $sftpfile ];then
      echo "err!file [$sftpfile] not exist!"
      exit 1
    fi
    cp $sftpfile $sftpdir
  else
    echo "err!type err![$sftptype]"
    exit 1
  fi
  sftptxt=$sftpdir/$filename.sftp
  curdir=`pwd`
  cd $sftpdir

  echo ' spawn sftp -oPort=22 '$sftpusr'@'$sftpip' ' >${sftptxt}
  echo ' expect { '   >>${sftptxt}
  echo ' "(yes/no)?" {send "yes\n";exp_continue}'  >>${sftptxt}
  echo ' "password:" {send "'$sftppwd'\n";exp_continue}'  >>${sftptxt}
  echo ' "sftp>" {send "pwd\n"} '  >>${sftptxt}
  echo ' }'  >>${sftptxt}
  echo ' expect "sftp>" '  >>${sftptxt}
  echo " send \"lcd ${sftpdir}  "'''\n''"'  >>${sftptxt}
  if [ "$sftprdir" != "" ];then
    echo ' expect "sftp>" '  >>${sftptxt}
    echo " send \"cd ${sftprdir}  "'''\n''"'  >>${sftptxt}
  fi
  echo ' expect "sftp>" '  >>${sftptxt}
  if [ "$sftptype" = "get" ];then
    if [ "$sftprdir" != "" ];then
      echo " send \"get $filename "'''\n''"'  >>${sftptxt}
    else
      echo " send \"get $sftpfile "'''\n''"'  >>${sftptxt}
    fi
  else
    echo " send \"mput $filename "'''\n''"'  >> $sftptxt
  fi
  echo ' expect "sftp>" '  >>${sftptxt}
  echo ' send "quit\n" '  >>${sftptxt}

  if [ "$sftptype" = "get" ];then
    #${HOME}/tools/bin/expect ${sftptxt}
    $toolsftpexpect ${sftptxt}
	cd $curdir
    exit 0
  fi

  sftptxt_OK=$sftptxt.ok
  num=0
  echo "�ļ�: $sftpfile ��ʼ����..."
  while [ 1 -eq 1 ]
  do
    num=$(expr $num + 1)
    #${HOME}/tools/bin/expect $sftptxt  >$sftptxt_OK
    $toolsftpexpect $sftptxt  >$sftptxt_OK
    grep "$sftpfile" $sftptxt_OK|grep "100%"
    if [ $? -ne 0 ]
    then
      echo "��$num��sftp �������,sftp ʧ��!!"
      if [ $num -ge $sftpputnum ]
      then
        echo "�ش��ļ�������,��$num��,SFTP����ʧ��"
        echo "�ļ�: $sftpfile ����ʧ��..."
		cd $curdir
        exit 1
      fi
      sleep 3
    else
      echo "��$num��sftp ����ɹ�SUCESS!!"
      echo "�ļ�: $sftpfile ����ɹ�,���..."
	  cd $curdir
      exit 0
    fi
  done
}

#11.��ȡ��̬����,���sh������������ű����Ƿ��в�������tippara���������̬��ȡ����
function getdynpara
{
  tagfile=$1
  tag=$2
  begin="#:"$tag":sh:"
  >$tfile
  jj=$(sed -n '/^'$begin'/,/^#:/'p $tagfile|sed -n '/^tippara=\"/p'|wc -l|awk '{print $1}')
  ii=1
  while [ $ii -le $jj ]
  do
  tipparadesc=$(sed -n '/^'$begin'/,/^#:/'p $tagfile|sed -n '/^tippara=\"/p'|head -$ii|tail -1|cut -c9-)
  tipparadesc=$(trimtail "$tipparadesc")
  tippara=$(echo "$tipparadesc"|cut -c2-$(expr $(expr length "$tipparadesc") - 1))
  i=1
  while [ $i -le $(echo $tippara|awk -F, '{print NF}') ]
  do
    tip=$(echo $tippara|awk -F, '{print $('$i')}')
    echo $tip|awk -F, '{printf "%s:",$1}'
    read onetip
    if [ $i -eq 1 ];then
      tipline="$onetip"
    else
      tipline="$tipline""""$onetip"
    fi
    i=$(expr $i + 1)
  done
  if [ $(expr length "$tipline") -eq 0 ];then
    echo "" >>$tfile
  else
    echo "$tipline" >>$tfile
  fi
  echo "--------------------------------------------------------------------------------"
  ii=$(expr $ii + 1)
  done
}

################################################################################
##5.������
################################################################################
#1.�ȵ�ָ���
#1.1 ��ӡʹ��˵��
if [ $# -eq 0 ];then Tooluse;exit 0;fi

#1.2.user�ȵ�ָ���
if [ "$1" = "user" ];then
  if [ $# -eq 1 ];then
    sed -n '/^#:aeuserinfo:const:/,/^#:/p' $zfile|head -1
    sed -n '/^#:aeuserinfo:const:/,/^#:/p' $zfile|grep -v "^#"|awk '{printf "%-15s %s %-12s xxxxxx %-11s %s\n",$1,$2,$3,$5,$6}'
    exit 0
  elif [ $# -eq 2 -a "$2" = "login" ];then
    sfile=$tooldir/s$ipstring.txt
    dealsecondlogin
    exit 0
  elif [ $# -eq 2 -a "$2" = "modify" -a "$usemode" = "0" ];then 
    dealfirstlogin 1;
    exit 0
  else
    echo "err!para err![$2]"
    exit 1
  fi
fi

#1.3.���û���Ϣע��
if [ $(sed -n '/^#:aeuserinfo:const:/,/^#:/p' $zfile|grep -v "^#"|awk '$1=="'$srcipstring'"'|wc -l|awk '{print $1}') -le 0 -a "$usemode" = "0" ];then
  dealfirstlogin 0
  exit 0
fi

#1.4.�鿴ϵͳ��Ϣ
if [ $# -eq 1 -a "$1" = "uname" ];then echo "AESO";exit 0;fi
if [ $# -eq 1 -a "$1" = "whoami" ];then echo $loginname;exit 0;fi
if [ $# -eq 3 -a "$1" = "who" -a "$2" = "am" -a "$3" = "i" ];then
  echo "$loginname $logindir $(date +%b) $(date +%d) $(date +%X) ($srcipstring)"
  exit 0
fi

#1.5 ϵͳ�ļ�Ȩ�޼�� ϵͳ�ļ�ֻ����admin�û��ſ����޸�
if [ "$1" = "z" -a "$srcipstring" != "$tooladminip" ];then
  if [ "$2" = "vi" -o "$3" = "del" -o "$2" = "s" -o $# -eq 1 ];then
    echo "err!you have no power to edit tool system file!"
    echo "please call tool admin to deal it![$tooladminname]";
    exit 1
  fi
fi

#1.6 ��ȡ��̬����,ÿ�ж�̬����֮����^^���ŷָ�
if [ $# -eq 3 -a "$1" = "para" -a $(isdigit "$2") -eq 1 -a $(isdigit "$3") -eq 1 ];then
  if [ -f $tfile ];then
    sed -n ''$2','$2''p $tfile|awk -F '{print $('$3')}'
  fi
  exit 0
fi

#1.7 �鿴�ļ����� 1-��ʱ�ļ�txt,2-��ʱ�ļ�sh,3-���ļ�,4-ϵͳ���ļ�,0-�ǹ����ļ�
if [ $# -eq 2 -a "$1" = "filetype" ];then
  if [ "$2" = "s" -o "$2" = "t" -o "$2" = "d" -o "$2" = "a" ];then
	filetype=1
  elif [ "$2" = "g" ];then
	filetype=2
  elif [ "$2" = "b" -o "$2" = "f" -o "$2" = "c" -o "$2" = "p" ];then
	filetype=3
  elif [ "$2" = "z" ];then
	filetype=4
  else
	filetype=0
  fi
  echo $filetype
  exit 0
fi

#2 �ļ�Ŀ¼����������鿴
if [ ! -f $sfile ];then >$sfile;fi
if [ ! -f $tfile ];then >$tfile;fi
if [ ! -f $dfile ];then >$dfile;fi
if [ ! -f $afile ];then >$afile;fi
if [ ! -f $gfile ];then >$gfile;chmod u+x $gfile;fi
if [ ! -f $bfile ];then >$bfile;fi
if [ ! -f $ffile ];then >$ffile;fi
if [ ! -f $cfile ];then >$cfile;fi
if [ ! -f $pfile ];then >$pfile;fi
if [ ! -f $zfile ];then >$zfile;fi
if [ $# -eq 1 ];then
  if   [ "$1" = "tool"     ];then echo $toolname ;exit 0;
  elif [ "$1" = "home"     ];then echo $homedir  ;exit 0;
  elif [ "$1" = "toolhome" ];then echo $tooldir  ;exit 0;
  elif [ "$1" = "bak"  ];then 
    cp $bfile  $bfile.$current
    cp $ffile  $ffile.$current
    cp $cfile  $cfile.$current
    cp $pfile  $pfile.$current
    mv $bfile.$current $homebakdir
    mv $ffile.$current $homebakdir
    mv $cfile.$current $homebakdir
    mv $pfile.$current $homebakdir
    echo "bak success!"
    exit 0;
  elif [ "$1" = "toolbak" ];then 
    cp $toolname $toolname.$current
    cp $zfile  $zfile.$current
    mv $toolname.$current $toolbakdir
    mv $zfile.$current    $toolbakdir
    echo "toolbak success!"
    exit 0
  fi
fi

#4 �����ļ��鿴���༭����ա�����(tag ����)
f1file=""
f1type=0
if   [ "$1" = "s" ];then f1file=$sfile;f1type=1;
elif [ "$1" = "t" ];then f1file=$tfile;f1type=1;
elif [ "$1" = "d" ];then f1file=$dfile;f1type=1;
elif [ "$1" = "a" ];then f1file=$afile;f1type=1;
elif [ "$1" = "g" ];then f1file=$gfile;f1type=2;
elif [ "$1" = "b" ];then f1file=$bfile;f1type=3;
elif [ "$1" = "f" ];then f1file=$ffile;f1type=3;
elif [ "$1" = "c" ];then f1file=$cfile;f1type=3;
elif [ "$1" = "p" ];then f1file=$pfile;f1type=3;
elif [ "$1" = "z" ];then f1file=$zfile;f1type=4;
#elif [ "$1" = "x" ];then 
#echo $x
#if [ -f "$x" ];then
#f1file=$x
#else
#f1file=$ffile;
#fi
#f1type=3;
#else f1type=0;
fi
f2file=""
f2type=0
if   [ "$2" = "s" ];then f2file=$sfile;f2type=1;
elif [ "$2" = "t" ];then f2file=$tfile;f2type=1;
elif [ "$2" = "d" ];then f2file=$dfile;f2type=1;
elif [ "$2" = "a" ];then f2file=$afile;f2type=1;
elif [ "$2" = "g" ];then f2file=$gfile;f2type=2;
elif [ "$2" = "b" ];then f2file=$bfile;f2type=3;
elif [ "$2" = "f" ];then f2file=$ffile;f2type=3;
elif [ "$2" = "c" ];then f2file=$cfile;f2type=3;
elif [ "$2" = "p" ];then f2file=$pfile;f2type=3;
elif [ "$2" = "z" ];then f2file=$zfile;f2type=4;
else f2type=0;
fi

if [ "$1" = "filetype" -a $# -eq 2 ];then echo $f2type;exit 0;fi

if [ $f1type -gt 0 ];then
if   [ $# -eq 1 -a $f1type -ge 1 -a $f1type -le 4 ];then echo $f1file;exit 0;
elif [ $# -eq 2 -a $f1type -ge 1 -a $f1type -le 4 -a "$2" = "vi"   -a "$usemode" != "1" ];then vi $f1file;exit 0;
elif [ $# -eq 2 -a $f1type -ge 1 -a $f1type -le 4 -a "$2" = "view" ];then view $f1file;exit 0;
elif [ $# -eq 2 -a $f1type -ge 1 -a $f1type -le 2 -a "$2" = "trun" -a "$usemode" != "1" ];then >$f1file;exit 0;
elif [ $# -eq 2 -a $f1type -ge 1 -a $f1type -le 2 -a "$2" = "cat"  ];then cat $f1file;exit 0;
elif [ $# -eq 2 -a $f1type -ge 3 -a $f1type -le 4 -a "$2" = "cat"  ];then grep ^#: $f1file;exit 0;
elif [ $# -eq 3 -a $f1type -ge 3 -a $f1type -le 4 -a "$2" = "cat"  ];then grep ^#: $f1file|grep "$3";exit 0;
elif [ $# -eq 2 -a $f1type -ge 1 -a $f1type -le 2 -a "$2" = "echo" ];then dealecho $f1file; exit 0;
elif [ $# -eq 2 -a $f1type -ge 1 -a $f1type -le 2 -a "$2" = "ord"  ];then dealorder $f1file;exit 0;
elif [ $# -eq 2 -a $f1type -ge 2 -a $f1type -le 2 -a "$2" = "exec" ];then exec $f1file;exit 0;
elif [ $# -eq 3 -a $f1type -ge 1 -a $f1type -le 2 -a $f2type -ge 1 -a $f2type -le 2 -a "$3" = "diff" ];then diff $f1file $f2file;exit 0;
fi 

if [ "$usemode" != "1" ];then
if   [ $# -eq 2 -a $f1type -ge 1 -a $f1type -le 2 -a $f2type -ge 1 -a $f2type -le 2 -a "$f1file" != "$f2file" ];then cp $f2file $f1file;exit 0;
elif [ $# -eq 2 -a $f1type -ge 1 -a $f1type -le 2 -a -f $2 ];then cp $2 $f1file;exit 0;
elif [ $# -eq 3 -a $f1type -ge 1 -a $f1type -le 2 -a -f $2 -a "$3" = "1" ];then cat $2 >>$f1file;exit 0;
elif [ $# -eq 2 -a $f1type -ge 1 -a $f1type -le 2 -a $f2type -ge 3 -a $f2type -le 4 ];then sed -n '/^#:/ p' $f2file>$f1file;exit 0;
fi
fi

tagflag=0
if   [ $# -eq 2 -a $f1type -ge 3 -a $f1type -le 4 -a "$2" = "s" ];then tagflag=4;begin="#:"$2":";
elif [ $# -eq 2 -a $f1type -ge 3 -a $f1type -le 4 -a "$2" = "pg" ];then sed -n '/^#:/ p' $f1file;exit 0;
elif [ $# -ge 3 -a $f1type -ge 3 -a $f1type -le 4 -a $(islabel "$2") -eq 1 -a "$3" = "pg" ];then tagflag=6;begin="#:"$2":";
elif [ $# -eq 2 -a $f1type -ge 3 -a $f1type -le 4 -a $(islabel "$2") -eq 1 ];then tagflag=1;begin="#:"$2":";
elif [ $# -ge 3 -a $# -le 4 -a $f1type -ge 3 -a $f1type -le 4 -a $(islabel "$2") -eq 1 -a "$3" = "del"  ];then tagflag=3;begin="#:"$2":";
elif [ $# -ge 3 -a $# -le 4 -a $f1type -ge 3 -a $f1type -le 4 -a $(islabel "$2") -eq 1 -a "$3" = "sh"   ];then tagflag=2;begin="#:"$2":sh:";
elif [ $# -ge 3 -a $# -le 4 -a $f1type -ge 3 -a $f1type -le 4 -a $(islabel "$2") -eq 1 -a "$3" = "exec" ];then tagflag=5;begin="#:"$2":sh:";
fi
if [ $tagflag -gt 0 -a $tagflag -ne 4 ];then
  totline=$(sed -n '/^'$begin'/p' $f1file|wc -l|awk '{print $1}')
  if [ $totline -le 0 ];then
    echo "err!not find the tag![$2]"
    exit 1
  elif [ $totline -gt 1 ];then
    echo "err!there are more than one tags![$2]"
    exit 1
  fi
fi
if [ $tagflag -eq 2 -o $tagflag -eq 5 ];then
  if [ $# -eq 3 ];then
    getdynpara $f1file $2
  elif [ $(expr length "$4") -ge 0 ];then
    echo "$4"|sed 's/,//g' >$tfile
  else
    >$tfile
  fi
fi
if   [ $tagflag -eq 4 -a "$usemode" != "1" ];then savefiletag $f1file 1;exit 0;
elif [ $tagflag -eq 1 -a "$usemode" != "1" ];then getfiletag $f1file $2 >$sfile;>$tfile;cat $sfile;exit 0
elif [ $tagflag -eq 1 -a "$usemode" = "1" ];then getfiletag $f1file $2;>$tfile;exit 0
elif [ $tagflag -eq 3 -a "$usemode" != "1" ];then delfiletag $f1file $2 $4;exit 0;
elif [ $tagflag -eq 2 -a "$usemode" != "1" ];then sed -n '/^'$begin'/,/^#:/'p $f1file|sh; exit 0;
elif [ $tagflag -eq 5 -a "$usemode" != "1" ];then echo "#!/bin/sh" >$gfile;sed -n '/^'#:$2:'/,/^#:/'p $f1file|grep -v "^#:">>$gfile;exec $gfile;exit 0;
elif [ $tagflag -eq 6 ];then
  getfiletag $f1file $2 >$t1file
  cp $t1file $tfile
  shift
  shift
  i=3
  flag="-"
  while [ x$1 != x ]
  do
  if [ $(expr $i % 2) -eq 1 ];then
    if [ "$1" != "pg" ];then
  	  echo "err!para err![$1]";>$tfile;$RM $t1file 2>/dev/null;exit 0;
    fi
  else
    flag="$flag""-"
    cat $tfile|sed -n '/^'$flag:$1:'/,/^'$flag':/'p >$t1file
    if [ $(wc -l $t1file|awk '{print $1}') -le 0 ];then
  	  echo "err!not find the tag![$flag][$1]";>$tfile;$RM $t1file 2>/dev/null;exit 0;
    fi
    cp $t1file $tfile
  fi
  i=$(expr $i + 1)
  shift
  done
  head -1 $tfile
  if [ $(expr $i % 2) -eq 0 ];then
    flag="$flag""-"
  grep "^$flag:" $tfile
  else
  cat $tfile|grep -v "^$flag:"
  fi
  >$tfile;$RM $t1file 2>/dev/null;exit 0;
fi
fi

#5 ���ʽ����
p1deal=$(echo "$1"|sed 's/[0-9]//g')
if [ "$p1deal" = "" -a "$1" != "" ];then
format="$2"
format1="<!if(char)then{memset(%s,0x0,sizeof(%s));}elif(double)then{%s=0.0;}else{%s=0;}!>"
if [ $(islabel "$2") -eq 1 ];then
  if   [ "$2" = "memset"   ];then format="memset(%s,0x0,sizeof(%s));";
  elif [ "$2" = "strcpy"   ];then format="strcpy(%s,%s);";
  elif [ "$2" = "strncpy"  ];then format="strncpy(%s,%s,sizeof(\$1)-1);";
  elif [ "$2" = "printf"   ];then format="printf(\"%%s\$n\",%s);";
  elif [ "$2" = "sprintf"  ];then format="sprintf(%s,\"%%s\",%s);";
  elif [ "$2" = "initval"  ];then format="$format1";
  fi 
fi
if [ $(echo $1|sed 's/[0-9]//g'|awk '{print length($1)}') -gt 0  ];then
  echo "err!para err!4"
  exit 1
fi
FormatFile $sfile "$1" "$format" "$3"
exit 0
fi
if [ "$1" = "format" -a $# -eq 1 ];then
  cat<<format
  memset  "memset(%s,0x0,sizeof(%s));"
  strcpy  "strcpy(%s,%s);"
  strncpy "strncpy(%s,%s,sizeof(\\\$1)-1);"
  printf  "printf(\\\"%%s\\\$n\\\",%s);"
  sprintf "sprintf(%s,\\\"%%s\\\",%s);"
  cond1   "<!if(c1)then{f1}elif([c2])then{f2}else{f3}!>"
  cond2   "<!if([ -vie 1 c1 ]&&[ -vie 2 c2 ]||[-vie 3 c3 ])then{f1}elif(c2)then{f2}else{f3}!>"
  cond2   "<!if([ -vie 1 c1 ]&&[ -vie 2 c2 ]||[-vie 3 c3 ])then{f1}elif(c2)then{f2}else{f3}!>"
format
  exit 0;
fi

################################################################################
##6.���˹�����չ
################################################################################
#1 ���ݿ����
if [ "$1" = "sql" -a $# -eq 2 ];then runsql "$2";exit 0;fi
if [ "$1" = "tb" -a $# -eq 2 -a $(islabel "$2") -eq 1 ];then 
  sqlstr="select trim(lower(a.column_name))||' '||trim(a.data_type)||' '||trim(nvl(a.data_length,0))||' '||\
  replace(trim(nvl(b.comments,' ')),' ','') from all_tab_columns a,all_col_comments b where 1=1 and a.owner=b.owner \
  and a.table_name =upper('$2') and a.table_name =b.table_name and a.column_name=b.column_name order by a.column_id"
  runsql "$sqlstr"
  exit 0
fi
if [ "$1" = "cal" -a $# -eq 2 ];then
  calstr=$(echo "$2"|sed 's/ //g')
  sqlstr="select $calstr result from dual"
  runsql "$sqlstr"|awk '{print $1}'|sed 's/^\./0\./'
  exit 0
fi

#2 ftp����
if [ "$1" = "ftp"  -a $# -eq 1 ];then echo $ftpdir;exit 0;fi
if [ "$1" = "ftp"  -a "$2" = "send" -a $# -eq 2 ];then echo $ftpsenddir;exit 0;fi
if [ "$1" = "ftp"  -a "$2" = "recv" -a $# -eq 2 ];then echo $ftprecvdir;exit 0;fi
if [ "$1" = "ftp"  -a "$2" = "get" -a $# -le 7 ];then runftp $2 $3 $4 $5 $6 $7   ;exit 0;fi
if [ "$1" = "ftp"  -a "$2" = "put" -a $# -le 8 ];then runftp $2 $3 $4 $5 $6 $7 $8;exit 0;fi
if [ "$1" = "sftp" -a "$2" = "get" -a $# -le 7 ];then runsftp "$2" "$3" "$4" "$5" "$6" "$7"     ;exit 0;fi
if [ "$1" = "sftp" -a "$2" = "put" -a $# -le 8 ];then runsftp "$2" "$3" "$4" "$5" "$6" "$7" "$8";exit 0;fi

#3 ��ȡsfile�ļ��е��������� ,1-��ָ���ַ���ͷ,""-�����ִ�Сд�����ַ�������,�����ֶζ�û�����ִ�Сд
if [ "$1" = "find" -a "$2" != "format" -a $(islabel "$2") -eq 1 ];then
  str2=$(lower $2)
  len2=$(expr length "$2") 1>/dev/null 2>&1
  #cat $sfile|grep -i $2|sed 's/[,.:!@#%^*-+=/{}[\ \  \(\)\"\|\;\&]/ /g'|sed "s/'/ /g"|while read line
  cat $sfile|grep -i $2|sed 's/[,.:!@#%^*-+=/{}[\ \  \(\)\"\|\;\&\<\>]/ /g'|sed "s/'/ /g"|while read line
  do
    fieldnum=$(echo "$line"|awk '{print NF}')
    i=1
    while [ $i -le $fieldnum ]
    do
      field=$(echo "$line"|awk '{print $'$i'}')
      if [ "$field" != "" ];then
        if [ "$3" = "" ];then
          if [ $(strstr $field $2 1) -eq 1 ];then
            echo $field
          fi
        elif [ "$3" = "1" ];then
          str1=$(lower $field)
          str3=$(echo "$str1"|cut -c1-$len2)
          if [ "$str3" =  "$str2" ];then
            echo $field
          fi
        fi
      fi
      i=$(expr $i + 1 )
    done
  done
  exit 0;
fi
echo "err!para err!5[$usemode]"
exit 1

